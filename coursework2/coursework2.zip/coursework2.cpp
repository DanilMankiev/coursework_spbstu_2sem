#include <iostream>
#include"Data\DataBase.h"
#include"logics\GameAlgorithm.h"
#include"logics\OutIn.h"
#include"app\app.h"
#include"menu\menu.h"

using namespace std;
int main()
{
	menu tmp;
	tmp.getwin();
	tmp.window();
}
